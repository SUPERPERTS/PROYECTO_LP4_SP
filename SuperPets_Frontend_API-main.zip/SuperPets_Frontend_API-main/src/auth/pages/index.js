/* Archivo de barril para pages-auth */

export * from './LoginPage';