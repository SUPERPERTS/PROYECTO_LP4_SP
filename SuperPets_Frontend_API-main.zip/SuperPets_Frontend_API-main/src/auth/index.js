/* Archivo de barril para api */

export * from './pages';