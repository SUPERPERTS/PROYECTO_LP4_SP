## h2 Carpeta Media

Vamos a utilizar esta carpeta para almacenar todo lo relacionado a las imagenes que vamos a utilizar para mostrar los productos