/* Arcchivo de barril para routes-api */

export * from './ApiRoutes';