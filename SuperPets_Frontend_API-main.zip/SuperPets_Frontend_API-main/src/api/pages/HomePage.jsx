import { Button, Container, Typography } from "@mui/material";

export const HomePage = () => {
  return (
    <>
      <Typography variant="h3">HomePage</Typography>
    </>
  );
};
