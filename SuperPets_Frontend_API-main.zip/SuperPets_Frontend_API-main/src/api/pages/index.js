/**
 * Archivo de barril para pages del api
 */

export * from './HomePage';