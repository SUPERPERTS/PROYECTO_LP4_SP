/* Archivo de barril para el api */

export * from './pages';
export * from './routes';
export * from './components';