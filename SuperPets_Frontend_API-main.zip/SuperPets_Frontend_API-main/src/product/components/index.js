/* Archivo de barril para componetnts - product */

export * from './ProductList';