/* Archivo de barril para pages-products */

export * from './ProductPage';
export * from './ProductsListPage';