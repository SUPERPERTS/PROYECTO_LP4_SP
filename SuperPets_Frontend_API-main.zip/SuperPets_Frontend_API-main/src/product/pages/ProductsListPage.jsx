import { Typography } from "@mui/material"

export const ProductsListPage = () => {
  return (
    <>
        <Typography variant="h3">ProductsListPage</Typography>
    </>
  )
}