/* archivo de bariil para product */

export * from "./routes";
export * from "./pages";
export * from "./components";
export * from "./helpers";
