/* Archivo bariil de routes-product */

export * from './ProductsRoutes';